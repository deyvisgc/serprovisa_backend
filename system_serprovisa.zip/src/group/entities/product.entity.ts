export class Product {
  id_prod: number;
  cod_product: string;
  name_product: string;
  des_product: string;
  status_product: string;
  group_id_group: number;
  user_id_user: number;
  correlativo: number;
  fech_regis: Date
}
