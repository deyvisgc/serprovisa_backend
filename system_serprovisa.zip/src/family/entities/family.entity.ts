export class Family {
  id_fam: number;
  cod_fam: string;
  des_fam: string;
  status_fam:string
}
