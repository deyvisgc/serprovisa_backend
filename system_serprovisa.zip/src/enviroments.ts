export const enviroments = {
  dev: '.env',
  prod: '.prod.env',
};
