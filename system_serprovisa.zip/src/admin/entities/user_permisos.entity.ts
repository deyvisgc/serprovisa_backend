

export class UsersPermisos {
  id_user: number;
  id_permission: number;
  modulo: number;
}
  