

export class Permisos {
  id_permission: number;
  permission_name: string;
}
  