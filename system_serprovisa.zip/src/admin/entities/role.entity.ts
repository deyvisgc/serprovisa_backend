

export class Role {
    id_role: number;
    ro_name: string;
    ro_status:string;
  }
  