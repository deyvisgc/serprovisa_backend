export enum ConstantsEnum {
    provideConnection = 'CONNECTION',
  }
  export enum TableEnum {
    provideConnection = 'CONNECTION',
    PRODUCTO='products',
    FAMILIA='family',
    LINEA='linea',
    GRUPO='group_produc',
    USERS='users',
    ROLE='rol',
    PERMISOS='permissions',
    USERS_PERMISOS='user_permissions'
  }