import { Family } from "../../family/entities/family.entity";

export class Linea {
    id_line: number;
    cod_line: string;
    des_line: string;
    status_line:string;
    family_id_fam: Family
  }
  