export class Response {
    cod: number;
    status: boolean;
    message:string
  }
  