

export class Users {
  id_user: number;
  us_username: string;
  us_full_name:string;
  us_avatar: string;
  role_idrole: number;
  us_fec_regis: Date;
  us_password: string;
}
