export class Group {
  id_grou: number;
  cod_gru: string;
  des_gru: string;
  status_gru: string;
  linea_id_line: number;
  fec_regis: Date;
  fam_id_familia: number
}
